#ifndef __WIFI_H
#define __WIFI_H
void wifi_init(void);
#endif
